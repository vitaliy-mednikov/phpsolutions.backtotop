<?
///////////////////////////////////////////////
//   Copyright (c) 2012-2014 PHP Solutions   //
//   ���������: support@phpsolutions.ru      //
///////////////////////////////////////////////

$arModuleVersion = array(
	"VERSION" => "1.0.0",
	"VERSION_DATE" => "2014-08-29 16:30:00"
);

?>